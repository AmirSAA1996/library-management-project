package savoir.maghreb.itis.model;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.sun.istack.NotNull;

import lombok.Data;

@Entity
@Data
@Table(name = "book")
public class BookEntity {
	
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @NotNull
    private Long id;  
    @NotNull
    private String isbn;
    @NotNull
    private String title;
    @NotNull
    private String resume;
    @NotNull 
    private Long Category_id;
    @NotNull 
    private Long Langue_id;
    @NotNull 
    private Date date_publication;
    @NotNull 
    private Long user_id;
    @NotNull 
    private Long userRole_id;
    @NotNull 
    private String keyword;
    @NotNull
    private String publisher;
    @NotNull
    private String nbreOfpages;
    
    @ManyToOne @JoinColumn(name="id", nullable=false, insertable = false, updatable=false)
    private ThemeEntity themeObject;
    
    // Getters & Setters
    
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getResume() {
		return resume;
	}
	public void setResume(String resume) {
		this.resume = resume;
	}
	public Long getCategory_id() {
		return Category_id;
	}
	public void setCategory_id(Long category_id) {
		Category_id = category_id;
	}
	public Long getLangue_id() {
		return Langue_id;
	}
	public void setLangue_id(Long langue_id) {
		Langue_id = langue_id;
	}
	public Date getDate_publication() {
		return date_publication;
	}
	public void setDate_publication(Date date_publication) {
		this.date_publication = date_publication;
	}
	public Long getUser_id() {
		return user_id;
	}
	public void setUser_id(Long user_id) {
		this.user_id = user_id;
	}
	public Long getUserRole_id() {
		return userRole_id;
	}
	public void setUserRole_id(Long userRole_id) {
		this.userRole_id = userRole_id;
	}
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public String getNbreOfpages() {
		return nbreOfpages;
	}
	public void setNbreOfpages(String nbreOfpages) {
		this.nbreOfpages = nbreOfpages;
	}
    
    
	
	

    
	
	

    
    

}
