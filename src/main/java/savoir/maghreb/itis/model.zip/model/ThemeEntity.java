package savoir.maghreb.itis.model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.sun.istack.NotNull;

import lombok.Data;

@Entity
@Data
@Table(name = "theme")
public class ThemeEntity {

	// Attributs
	
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @NotNull
    private Long id;  
    @NotNull
    private String name;
    
    
    @OneToMany ( targetEntity=BookEntity.class,cascade = CascadeType.ALL,
            fetch = FetchType.LAZY, mappedBy= "themeObject")
    private Set<BookEntity> BookList = new HashSet<>();
    
    // Getters et Setters
    

    
	public Long getId() {
		return id;
	}

	public Set<BookEntity> getBookList() {
		return BookList;
	}

	public void setBookList(Set<BookEntity> bookList) {
		BookList = bookList;
	}

	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
    
    
	
}
